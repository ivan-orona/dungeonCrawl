﻿/**
* October 2, 2018
* CSC 253
* Michael Villafan & Ivan Orona
* This program will display a prompt message for the user to use two different
* keys to maneuvar through a console interface with an option to quit. The 
* program will allow the user to move back and forth in between rooms 
* while also informing the player where they are.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        //Used for array index
        static int globalINT = 0;
        static int inventoryLimit = 7;
        static string userInput = "";
        static Random random = new Random();

        //Arrays for rooms, weapons, potions and treasures
        static String[] roomArray = new string[] { "Town", "Wilderness", "Cave", "Abandoned Church", "Boss Lair" };
        static String[] weaponArray = new string[] { "Sword", "Bow", "Mace", "Battle Axe" };
        static String[] potionArray = new string[] { "Mana Potion", "Health Potion" };
        static String[] treasureArray = new string[] { "Magic Key", "Strength Stone", "Black Gem" };
        //Lists for items and mobs
        static List<string> items = new List<string>();
        static List<string> mobs = new List<string>();
        static List<string> weaponsInventory = new List<string>();
        static List<string> items_potionsInventory = new List<string>();
        static List<string> treasureInventory = new List<string>();

        static void Main(string[] args)
        {
            //add items to listss
            items.Add("Town Portal");
            items.Add("Boss Portal");
            items.Add("Ameulet");
            items.Add("Ring");
            mobs.Add("Zombie");
            mobs.Add("Skeleton");
            mobs.Add("Ghost");
            mobs.Add("Lesser Demon");
            mobs.Add("Giant Spider");

            Console.WriteLine("Your adventure has begun");

            gameState(globalINT);
            
            
        }//Main Bracket

        private static void gameState(int index)
        {
            Console.WriteLine("You are currently in: " + roomArray[index]);
            Console.WriteLine("your commands are N for north, S for South and E for exit");
            try
            {
                userInput = Console.ReadLine().ToLower();

                //If user wants to move North, we add + 1 to the global variable thats holds the current index of the array, then calls gamState()
                if (userInput == "n")
                {
                    if (globalINT < 4)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        globalINT = globalINT + 1; 
                        gameState(globalINT);


                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out North");
                        gameState(globalINT);

                    }
                }
                //If user wants to move south, we subtract - 1 to the global variable that holds the current index of the array, then calls gamState().
                if (userInput == "s")
                {
                    if (globalINT > 0)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        globalINT = globalINT - 1;
                        gameState(globalINT);

                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out South");
                        gameState(globalINT);
                    }
                }
                //Used for exiting application
                if (userInput == "e")
                {
                    Console.WriteLine("Good Bye");
                    Environment.Exit(0);
                }
            }
            //Catch any error and will display message.
            catch
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Incorrect input! Your commands are N for North S for South and E for exit");
                gameState(globalINT);
            }

        }
    }
}
//End program.